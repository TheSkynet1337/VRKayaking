---
marp: true
theme: uncover
class: invert
style: |
  video::-webkit-media-controls {
    will-change: transform;
  }
---
# IARVR Update
<span style="color:grey"> By:</span> Tobias Güdelhöfer

---
# Locomotion
---
## What I have done
* No Pole
* First implementation of locomotion

---

<video src="2022-12-19 18-37-44.mp4" controls width="100%"></video>

---
## What I want to do
* Tweak locomotion so it is not as icy
* Build a Pole  
---

## Interaction
* No implementation so far
* Plan is still to induce Gorilla Arm
* 3 checkpoints that user has to move pole to and hold for period of time at each
---
# Thank You!